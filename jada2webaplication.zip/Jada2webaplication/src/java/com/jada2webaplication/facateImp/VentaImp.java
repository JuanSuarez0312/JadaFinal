package com.jada2webaplication.facateImp;

import com.jada2webaplication.entity.Venta;
import com.jada2webaplication.facade.IVenta;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

@Named
@ApplicationScoped
public class VentaImp implements IVenta {

    private List<Venta> listVenta = new ArrayList<Venta>();
    @PersistenceContext(unitName = "Jada2webaplicationPU")
    private EntityManager em;

    private Query q;

    @Override
    public List<Venta> findAll() throws Exception {
        this.q = this.em.createQuery("SELECT v FROM Venta v");
        this.listVenta = q.getResultList();
        return this.listVenta;
    }

    @Override
    public Venta findById(int id) throws Exception {
        Venta venta = new Venta();
        venta = this.em.find(Venta.class, id);
        return venta;
    }

    @Override
    @Transactional
    public void add(Venta venta) throws Exception {
        this.em.persist(venta);
    }

    @Override
    @Transactional
    public void update(Venta venta) throws Exception {
        this.em.merge(venta);
    }

    @Override
    @Transactional
    public void delete(Venta venta) throws Exception {
        Venta ve = new Venta();
        ve = this.em.find(Venta.class, ve.getId());
        if (ve != null) {
            this.em.remove(ve);
        }
    }

}
