package com.jada2webaplication.facateImp;

import com.jada2webaplication.entity.Catalogo;
import com.jada2webaplication.facade.ICatalogo;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

@Named
@ApplicationScoped
public class CatalogoImp implements ICatalogo {

    private List<Catalogo> listCatalogo = new ArrayList<Catalogo>();
    @PersistenceContext(unitName = "Jada2webaplicationPU")
    private EntityManager em;

    private Query q;

    @Override
    public List<Catalogo> findAll() throws Exception {
        this.q = this.em.createQuery("SELECT c FROM Catalogo c");
        this.listCatalogo = q.getResultList();
        return this.listCatalogo;
    }

    @Override
    public Catalogo findById(int id) throws Exception {
        Catalogo catalogo = new Catalogo();
        catalogo = this.em.find(Catalogo.class, id);
        return catalogo;
    }

    @Transactional
    @Override
    public void add(Catalogo catalogo) throws Exception {
        this.em.persist(catalogo);
    }

    @Transactional
    @Override
    public void update(Catalogo catalogo) throws Exception {
        this.em.merge(catalogo);
    }

    
    @Override
    @Transactional
    public void delete(Catalogo catalogo) throws Exception {
        Catalogo c = new Catalogo();
        System.out.println("@@%" + catalogo.toString());
        c = this.em.find(Catalogo.class, catalogo.getId_Catalogo());
        if (c != null) {
            this.em.remove(c);
        }
    }
}
