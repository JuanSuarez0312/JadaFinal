package com.jada2webaplication.facateImp;

import com.jada2webaplication.entity.Producto;
import com.jada2webaplication.facade.IProducto;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

@Named
@ApplicationScoped
public class ProductoImp implements IProducto {

    private List<Producto> listProducto = new ArrayList<Producto>();
    @PersistenceContext(unitName = "Jada2webaplicationPU")
    private EntityManager em;

    private Query q;

    @Override
    public List<Producto> findAll() throws Exception {
        this.q = this.em.createQuery("SELECT pro FROM Producto pro");
        this.listProducto = q.getResultList();
        return this.listProducto;
    }

    @Override
    public Producto findById(int id) throws Exception {
        Producto producto = new Producto();
        producto = this.em.find(Producto.class, id);
        return producto;
    }

    @Override
    @Transactional
    public void add(Producto producto) throws Exception {
        this.em.persist(producto);
    }

    @Override
    @Transactional
    public void update(Producto producto) throws Exception {
        this.em.merge(producto);
    }

    @Override
    @Transactional
    public void delete(Producto producto) throws Exception {
        Producto pro = new Producto();
        pro = this.em.find(Producto.class, pro.getId_Producto());
        if (pro != null) {
            this.em.remove(pro);
        }
    }
}
