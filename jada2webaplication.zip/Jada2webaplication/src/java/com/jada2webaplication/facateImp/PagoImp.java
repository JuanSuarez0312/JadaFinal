package com.jada2webaplication.facateImp;

import com.jada2webaplication.entity.Pago;
import com.jada2webaplication.facade.IPago;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

@Named
@ApplicationScoped
public class PagoImp implements IPago {

    private List<Pago> listPago = new ArrayList<Pago>();
    @PersistenceContext(unitName = "Jada2webaplicationPU")
    private EntityManager em;

    private Query q;

    @Override
    public List<Pago> findAll() throws Exception {
        this.q = this.em.createQuery("SELECT pa FROM Pago pa");
        this.listPago = q.getResultList();
        return this.listPago;
    }

    @Override
    public Pago findById(int id) throws Exception {
        Pago pago = new Pago();
        pago = this.em.find(Pago.class, id);
        return pago;
    }

    @Override
    @Transactional
    public void add(Pago pago) throws Exception {
        this.em.persist(pago);
    }

    @Override
    @Transactional
    public void update(Pago pago) throws Exception {
        this.em.merge(pago);
    }

    @Override
    @Transactional
    public void delete(Pago pago) throws Exception {
        Pago pa = new Pago();
        pa = this.em.find(Pago.class, pago.getId_Pago());
        if (pa != null) {
            this.em.remove(pa);
        }
    }

}
