package com.jada2webaplication.facateImp;

import com.jada2webaplication.entity.Usuario;
import com.jada2webaplication.facade.IUsuario;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

@Named
@ApplicationScoped
public class UsuarioImp implements IUsuario {

    private List<Usuario> listUsuarios = new ArrayList<Usuario>();
    @PersistenceContext(unitName = "Jada2webaplicationPU")
    private EntityManager em;

    private Query q;

    @Override
    public List<Usuario> findAll() throws Exception {
        this.q = this.em.createQuery("SELECT u FROM Usuario u");
        this.listUsuarios = q.getResultList();
        return this.listUsuarios;

    }

    @Override
    public Usuario findById(int id) throws Exception {
        Usuario usuario = new Usuario();
        usuario = this.em.find(Usuario.class, id);
        return usuario;
    }

    @Transactional
    @Override
    public void add(Usuario user) throws Exception {
        this.em.persist(user);
    }

    @Override
    @Transactional
    public void update(Usuario user) throws Exception {
        this.em.merge(user);

    }

    @Override
    @Transactional
    public void delete(Usuario user) throws Exception {
        Usuario u = new Usuario();
        u = this.em.find(Usuario.class, user.getId());
        if (u != null) {
            this.em.remove(u);
        }
    }

    @Override
    public Usuario validarUsuario(Usuario usuario) throws Exception {
        Usuario us = null;
        String condicion;
        Query q;
        condicion = "SELECT u FROM Usuario u WHERE u.correo=?1 and u.contraseña=?2";
        q = this.em.createQuery(condicion);
        q.setParameter(1, usuario.getCorreo());
        q.setParameter(2, usuario.getContraseña());
        List<Usuario> listUsu = q.getResultList();
        if (!listUsu.isEmpty()) {
            us = listUsu.get(0);
        }
        return us;
    }

    @Override
    public Usuario userByEmail(Usuario user) throws Exception {
        Usuario usPass = null;
        String consulta = "SELECT u FROM Usuario u where u.correo =?1";
        Query q;

        q = this.em.createQuery(consulta);
        q.setParameter(1, user.getCorreo());

        List<Usuario> listUsuByPass = q.getResultList();

        if (!listUsuByPass.isEmpty()) {
            usPass = listUsuByPass.get(0);
        }
        return usPass;
    }
    
    @Override
    public Usuario mostrarInfoCliente(Usuario user) throws Exception {
        Usuario miUsuario = null;
        String consulta = "SELECT u FROM Usuario u where u.Id_Usuario =?1";
        Query q;
        
        q = this.em.createQuery(consulta);
        q.setParameter(1, user.getId_Usuario());
        
        List<Usuario> listMiUsuario = q.getResultList();
        
        if (!listMiUsuario.isEmpty()) {
            miUsuario = listMiUsuario.get(0);
        }
        return miUsuario;
    }
}
