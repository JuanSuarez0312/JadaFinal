package com.jada2webaplication.facateImp;

import com.jada2webaplication.entity.Pqr;
import com.jada2webaplication.facade.IPqr;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

@Named
@ApplicationScoped
public class PqrImp implements IPqr {

    private List<Pqr> listPqrs = new ArrayList<Pqr>();
    @PersistenceContext(unitName = "Jada2webaplicationPU")
    private EntityManager em;

    private Query q;

    @Override

    public List<Pqr> findAll() throws Exception {
        this.q = this.em.createQuery("SELECT p FROM Pqr p");
        this.listPqrs = q.getResultList();
        return this.listPqrs;
    }

    @Override
    public Pqr findById(int id) throws Exception {
        Pqr pqr = new Pqr();
        pqr = this.em.find(Pqr.class, id);
        return pqr;
    }

    @Override
    @Transactional
    public void add(Pqr pqr) throws Exception {
        this.em.persist(pqr);
    }

    @Override
    @Transactional
    public void update(Pqr pqr) throws Exception {
        this.em.merge(pqr);
    }

    @Override
    @Transactional
    public void delete(Pqr pqr) throws Exception {
        Pqr pq = new Pqr();
        System.out.println("@@" + pq.toString());
        pq = this.em.find(Pqr.class, pqr.getId_Pqrs());
        if (pq != null) {
            this.em.remove(pq);
        }
    }

}
