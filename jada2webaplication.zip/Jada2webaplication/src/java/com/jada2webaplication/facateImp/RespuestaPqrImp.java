package com.jada2webaplication.facateImp;

import com.jada2webaplication.entity.RespuestaPqr;
import com.jada2webaplication.facade.IRespuestaPqr;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

@Named
@ApplicationScoped
public class RespuestaPqrImp implements IRespuestaPqr {

    private List<RespuestaPqr> listRespuestaPqr = new ArrayList<RespuestaPqr>();
    @PersistenceContext(unitName = "Jada2webaplicationPU")
    private EntityManager em;

    private Query q;

    @Override
    public List<RespuestaPqr> findAll() throws Exception {
        this.q = this.em.createQuery("SELECT rp FROM RespuestaPqr rp");
        this.listRespuestaPqr = q.getResultList();
        return this.listRespuestaPqr;
    }

    @Override
    public RespuestaPqr findById(int id) throws Exception {
        RespuestaPqr respuestaPqr = new RespuestaPqr();
        respuestaPqr = this.em.find(RespuestaPqr.class, id);
        return respuestaPqr;
    }

    @Override
    @Transactional
    public void add(RespuestaPqr respuestaPqr) throws Exception {
        this.em.merge(respuestaPqr);
    }

    @Override
    @Transactional
    public void update(RespuestaPqr respuestaPqr) throws Exception {
        this.em.merge(respuestaPqr);
    }

    @Override
    @Transactional
    public void delete(RespuestaPqr respuestaPqr) throws Exception {
        RespuestaPqr rp = new RespuestaPqr();
        rp = this.em.find(RespuestaPqr.class, respuestaPqr.getId_Respuesta());
        if (rp != null) {
            this.em.remove(rp);
        }
    }

}
