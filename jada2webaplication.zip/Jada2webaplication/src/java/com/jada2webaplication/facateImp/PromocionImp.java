package com.jada2webaplication.facateImp;

import com.jada2webaplication.entity.Promocion;
import com.jada2webaplication.facade.IPromocion;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

@Named
@ApplicationScoped
public class PromocionImp implements IPromocion {

    private List<Promocion> listPromocion = new ArrayList<Promocion>();
    @PersistenceContext(unitName = "Jada2webaplicationPU")
    private EntityManager em;

    private Query q;

    @Override
    public List<Promocion> findAll() throws Exception {
        this.q = this.em.createQuery("SELECT prom FROM Promocion prom");
        this.listPromocion = q.getResultList();
        return listPromocion;
    }

    @Override
    public Promocion findById(int id) throws Exception {
        Promocion promocion = new Promocion();
        promocion = this.em.find(Promocion.class, id);
        return promocion;
    }

    @Override
    @Transactional
    public void add(Promocion promocion) throws Exception {
        this.em.persist(promocion);
    }

    @Override
    @Transactional
    public void update(Promocion promocion) throws Exception {
        this.em.merge(promocion);
    }

    @Override
    @Transactional
    public void delete(Promocion promocion) throws Exception {
        Promocion prom = new Promocion();
        prom = this.em.find(Promocion.class, promocion.getId_Promociones());
        if (prom != null) {
            this.em.remove(prom);
        }
    }
}
