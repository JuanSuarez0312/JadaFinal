package com.jada2webaplication.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "producto")
public class Producto implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Id_Producto;
    @Column(name = "Nombre_Producto")
    private String nomProd;
    @Column(name = "Descripcion_Producto")
    private String descProd;
    @Column(name = "Precio")
    private int precio;
    @Column(name = "Cantidad_Stock")
    private int cantStock;
    @Column(name = "Imagen")
    private String imagen;

    @OneToMany(mappedBy = "Id_ProductoFk")
    private List<Venta> listVenta;

    @OneToMany(mappedBy = "Id_ProductoFk")
    private List<Promocion> listPromocion;

    @ManyToOne
    @JoinColumn(name = "Id_Catalogo", referencedColumnName = "Id_Catalogo")
    private Catalogo Id_CatalogoFk;

    public Producto() {
    }

    public Producto(int Id_Producto, String nomProd, String descProd, int precio, int cantStock, String imagen, List<Venta> listVenta, List<Promocion> listPromocion, Catalogo Id_CatalogoFk) {
        this.Id_Producto = Id_Producto;
        this.nomProd = nomProd;
        this.descProd = descProd;
        this.precio = precio;
        this.cantStock = cantStock;
        this.imagen = imagen;
        this.listVenta = listVenta;
        this.listPromocion = listPromocion;
        this.Id_CatalogoFk = Id_CatalogoFk;
    }

    public int getId_Producto() {
        return Id_Producto;
    }

    public void setId_Producto(int Id_Producto) {
        this.Id_Producto = Id_Producto;
    }

    public String getNomProd() {
        return nomProd;
    }

    public void setNomProd(String nomProd) {
        this.nomProd = nomProd;
    }

    public String getDescProd() {
        return descProd;
    }

    public void setDescProd(String descProd) {
        this.descProd = descProd;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getCantStock() {
        return cantStock;
    }

    public void setCantStock(int cantStock) {
        this.cantStock = cantStock;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public List<Venta> getListVenta() {
        return listVenta;
    }

    public void setListVenta(List<Venta> listVenta) {
        this.listVenta = listVenta;
    }

    public List<Promocion> getListPromocion() {
        return listPromocion;
    }

    public void setListPromocion(List<Promocion> listPromocion) {
        this.listPromocion = listPromocion;
    }

    public Catalogo getId_CatalogoFk() {
        return Id_CatalogoFk;
    }

    public void setId_CatalogoFk(Catalogo Id_CatalogoFk) {
        this.Id_CatalogoFk = Id_CatalogoFk;
    }

    

}
