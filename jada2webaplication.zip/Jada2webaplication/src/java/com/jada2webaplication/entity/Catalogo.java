package com.jada2webaplication.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "catalogo")
public class Catalogo implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Id_Catalogo;
    @Column(name = "Nombre_Catalogo")
    private String nomCatalogo;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "Fecha_Inicio_Catalogo")
    private Date fechaIni;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "Fecha_Fin_Catalogo")
    private Date fechaFin;

    @OneToMany(mappedBy = "Id_CatalogoFk")
    private List<Producto> listProductos;

    public Catalogo() {
    }

    public Catalogo(int Id_Catalogo, String nomCatalogo, Date fechaIni, Date fechaFin, List<Producto> listProductos) {
        this.Id_Catalogo = Id_Catalogo;
        this.nomCatalogo = nomCatalogo;
        this.fechaIni = fechaIni;
        this.fechaFin = fechaFin;
        this.listProductos = listProductos;
    }

    public int getId_Catalogo() {
        return Id_Catalogo;
    }

    public void setId_Catalogo(int Id_Catalogo) {
        this.Id_Catalogo = Id_Catalogo;
    }

    public String getNomCatalogo() {
        return nomCatalogo;
    }

    public void setNomCatalogo(String nomCatalogo) {
        this.nomCatalogo = nomCatalogo;
    }

    public Date getFechaIni() {
        return fechaIni;
    }

    public void setFechaIni(Date fechaIni) {
        this.fechaIni = fechaIni;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public List<Producto> getListProductos() {
        return listProductos;
    }

    public void setListProductos(List<Producto> listProductos) {
        this.listProductos = listProductos;
    }

    

}
