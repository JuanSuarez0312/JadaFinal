package com.jada2webaplication.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "ventas")
public class Venta implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Id_Venta;
    @Column(name = "Numero_Factura")
    private int numFactura;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "Fecha_Venta")
    private Date fechaVenta;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "Fecha_Entrega")
    private Date fechaEntrega;
    @Column(name = "Cantidad")
    private int cantidad;
    @Column(name = "Total")
    private Double Total;

    @OneToMany(mappedBy = "Id_VentaFk")
    private List<Pqr> listPqrs;

    @ManyToOne
    @JoinColumn(name = "Id_Producto", referencedColumnName = "Id_Producto")
    private Producto Id_ProductoFk;

    @ManyToOne
    @JoinColumn(name = "Id_Usuario", referencedColumnName = "Id_Usuario")
    private Usuario Id_UsuarioFk;

    @ManyToOne
    @JoinColumn(name = "Id_Pago", referencedColumnName = "Id_Pago")
    private Pago Id_PagoFk;

    public Venta() {
    }

    public Venta(int Id_Venta, int numFactura, Date fechaVenta, Date fechaEntrega, int cantidad, Double Total, List<Pqr> listPqrs, Producto Id_ProductoFk, Usuario Id_UsuarioFk, Pago Id_PagoFk) {
        this.Id_Venta = Id_Venta;
        this.numFactura = numFactura;
        this.fechaVenta = fechaVenta;
        this.fechaEntrega = fechaEntrega;
        this.cantidad = cantidad;
        this.Total = Total;
        this.listPqrs = listPqrs;
        this.Id_ProductoFk = Id_ProductoFk;
        this.Id_UsuarioFk = Id_UsuarioFk;
        this.Id_PagoFk = Id_PagoFk;
    }

    public int getId() {
        return Id_Venta;
    }

    public void setId(int id) {
        this.Id_Venta = id;
    }

    public int getNumFactura() {
        return numFactura;
    }

    public void setNumFactura(int numFactura) {
        this.numFactura = numFactura;
    }

    public Date getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(Date fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public Date getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(Date fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public Double getTotal() {
        return Total;
    }

    public void setTotal(Double Total) {
        this.Total = Total;
    }

    public List<Pqr> getListPqrs() {
        return listPqrs;
    }

    public void setListPqrs(List<Pqr> listPqrs) {
        this.listPqrs = listPqrs;
    }

    public int getId_Venta() {
        return Id_Venta;
    }

    public void setId_Venta(int Id_Venta) {
        this.Id_Venta = Id_Venta;
    }

    public Producto getId_ProductoFk() {
        return Id_ProductoFk;
    }

    public void setId_ProductoFk(Producto Id_ProductoFk) {
        this.Id_ProductoFk = Id_ProductoFk;
    }

    public Usuario getId_UsuarioFk() {
        return Id_UsuarioFk;
    }

    public void setId_UsuarioFk(Usuario Id_UsuarioFk) {
        this.Id_UsuarioFk = Id_UsuarioFk;
    }

    public Pago getId_PagoFk() {
        return Id_PagoFk;
    }

    public void setId_PagoFk(Pago Id_PagoFk) {
        this.Id_PagoFk = Id_PagoFk;
    }

}
