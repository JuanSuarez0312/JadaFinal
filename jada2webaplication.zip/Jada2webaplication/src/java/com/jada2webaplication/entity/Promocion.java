package com.jada2webaplication.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "promociones")
public class Promocion implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Id_Promociones;
    @Column(name = "Descuento")
    private Float descuento;
    @Column(name = "Puntos_Necesarios")
    private int puntosNecesarios;

    @ManyToOne
    @JoinColumn(name = "Id_Producto", referencedColumnName = "Id_Producto")
    private Producto Id_ProductoFk;

    public Promocion() {
    }

    public Promocion(int Id_Promociones, Float descuento, int puntosNecesarios, Producto Id_ProductoFk) {
        this.Id_Promociones = Id_Promociones;
        this.descuento = descuento;
        this.puntosNecesarios = puntosNecesarios;
        this.Id_ProductoFk = Id_ProductoFk;
    }

    public int getId_Promociones() {
        return Id_Promociones;
    }

    public void setId_Promociones(int Id_Promociones) {
        this.Id_Promociones = Id_Promociones;
    }

    public Float getDescuento() {
        return descuento;
    }

    public void setDescuento(Float descuento) {
        this.descuento = descuento;
    }

    public int getPuntosNecesarios() {
        return puntosNecesarios;
    }

    public void setPuntosNecesarios(int puntosNecesarios) {
        this.puntosNecesarios = puntosNecesarios;
    }

    public Producto getId_ProductoFk() {
        return Id_ProductoFk;
    }

    public void setId_ProductoFk(Producto Id_ProductoFk) {
        this.Id_ProductoFk = Id_ProductoFk;
    }

    

}
