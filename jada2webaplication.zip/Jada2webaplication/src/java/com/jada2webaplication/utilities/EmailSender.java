package com.jada2webaplication.utilities;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class EmailSender {
    
    public static boolean enviarEmail(String destinatario, String asunto, String cuerpo){
        String remitente = "jadamakeup2022@gmail.com";
        
        Properties props = System.getProperties();
        props.setProperty("mail.smtp.ssl.protocols", "TLSv1.2");
        props.put("mail.smtp.host", "smtp.gmail.com"); //servidor de gmail
        props.put("mail.smtp.ssl.trust", "*");
        props.put("mail.smtp.user", remitente);
        props.put("mail.smtp.clave", "whrgnxbkvjhohspx"); // clave de la cuenta
        props.put("mail.smtp.auth", "true"); // Usar autenticacion mediante usuario y clave
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.port","587");
        
        Session session = Session.getDefaultInstance(props);
        MimeMessage message = new MimeMessage(session);
        
        try {
            message.setFrom(new InternetAddress(remitente));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(destinatario));
            message.addRecipient(Message.RecipientType.CC, new InternetAddress("jpsp2000312@gmail.com"));
            message.setSubject(asunto);
            message.setText(cuerpo);
            Transport transport = session.getTransport("smtp");
            String clave = "whrgnxbkvjhohspx";
            transport.connect("smtp.gmail.com",remitente,clave);
            transport.sendMessage(message, message.getAllRecipients());
            transport.close();
            return true;
        } catch (MessagingException me) {
            me.printStackTrace();
            return false;
        }
    }
}
