package com.jada2webaplication.bean;

import com.jada2webaplication.entity.Pqr;
import com.jada2webaplication.entity.Usuario;
import com.jada2webaplication.entity.Venta;
import com.jada2webaplication.facateImp.PqrImp;
import com.jada2webaplication.facateImp.UsuarioImp;
import com.jada2webaplication.facateImp.VentaImp;
import java.io.Serializable;
import static java.time.LocalDate.now;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.PrimeFaces;

@Named("pqrBean")
@ViewScoped
public class PqrBean implements Serializable {

    private List<Pqr> pqrs;
    private List<Usuario> listUsuario;
    private List<Venta> listVenta;

    private Pqr pqr;
    private Usuario usuario;
    private Venta venta;

    private int Id_Usuario;
    private int Id_Venta;
    private int Id_Pqr;

    @Inject
    private PqrImp pqrImp;
    @Inject
    private UsuarioImp usuarioImp;
    @Inject
    private VentaImp ventaImp;

    @PostConstruct
    public void init() {
        try {
            this.listUsuario = this.usuarioImp.findAll();
            this.listVenta = this.ventaImp.findAll();
            this.pqrs = this.pqrImp.findAll();
            this.pqr = new Pqr();
            this.usuario = new Usuario();
            this.venta = new Venta();
        } catch (Exception e) {
            e.getMessage();
        }
    }

    public List<Pqr> getPqrs() {
        return pqrs;
    }

    public void setPqrs(List<Pqr> pqrs) {
        this.pqrs = pqrs;
    }

    public Pqr getPqr() {
        return pqr;
    }

    public void setPqr(Pqr pqr) {
        this.pqr = pqr;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Venta getVenta() {
        return venta;
    }

    public void setVenta(Venta venta) {
        this.venta = venta;
    }

    public List<Usuario> getListUsuario() {
        return listUsuario;
    }

    public void setListUsuario(List<Usuario> listUsuario) {
        this.listUsuario = listUsuario;
    }

    public List<Venta> getListVenta() {
        return listVenta;
    }

    public void setListVenta(List<Venta> listVenta) {
        this.listVenta = listVenta;
    }

    public int getId_Usuario() {
        return Id_Usuario;
    }

    public void setId_Usuario(int Id_Usuario) {
        this.Id_Usuario = Id_Usuario;
    }

    public int getId_Venta() {
        return Id_Venta;
    }

    public void setId_Venta(int Id_Venta) {
        this.Id_Venta = Id_Venta;
    }

    public int getId_Pqr() {
        return Id_Pqr;
    }

    public void setId_Pqr(int Id_Pqr) {
        this.Id_Pqr = Id_Pqr;
    }

    public PqrImp getPqrImp() {
        return pqrImp;
    }

    public void setPqrImp(PqrImp pqrImp) {
        this.pqrImp = pqrImp;
    }

    public UsuarioImp getUsuarioImp() {
        return usuarioImp;
    }

    public void setUsuarioImp(UsuarioImp usuarioImp) {
        this.usuarioImp = usuarioImp;
    }

    public VentaImp getVentaImp() {
        return ventaImp;
    }

    public void setVentaImp(VentaImp ventaImp) {
        this.ventaImp = ventaImp;
    }

    public void deletePqr(Pqr pqr) {
        try {
            this.pqrImp.delete(pqr);
            this.pqrs.remove(pqr);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("PQR Removed"));
            PrimeFaces.current().ajax().update("formPqr:messages", "formPqr:listPqr");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void añadirPqr() {
        try {
            this.pqr.setId_UsuarioFk(usuario);
            this.pqr.setId_VentaFk(venta);
            this.pqrImp.add(pqr);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro exitoso", "PQRS Registrada exitosamente"));
            PrimeFaces.current().ajax().update("formPqr:messages", "formPqr:listPqr");
            init();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Fallo", e.getMessage()));
        }
    }

    public void editarPqr() {
        try {
            usuario = this.usuarioImp.findById(Id_Usuario);
            venta = this.ventaImp.findById(Id_Venta);
            this.pqr.setId_UsuarioFk(usuario);
            this.pqr.setId_VentaFk(venta);
            this.pqrImp.update(this.pqr);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Modificacion exitosa", "PQRS Editada exitosamente"));
            PrimeFaces.current().ajax().update("formPqrs", "editPqrs");
            init();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Error", e.getMessage()));
        }
    }

    public void mostrarInfo(Pqr pqr) {
        try {
            this.pqr = this.pqrImp.findById(pqr.getId_Pqrs());
            this.Id_Usuario = this.pqr.getId_UsuarioFk().getId_Usuario();
            this.Id_Venta = this.pqr.getId_VentaFk().getId_Venta();
            PrimeFaces.current().ajax().update("editPqrs");
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Error", e.getMessage()));
        }
    }
    
    
}
