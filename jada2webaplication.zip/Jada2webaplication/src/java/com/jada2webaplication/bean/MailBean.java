package com.jada2webaplication.bean;

import com.jada2webaplication.utilities.EmailSender;
import java.io.Serializable;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;


@Named("mailBean")
@ViewScoped
public class MailBean implements Serializable{
    
    private String destino;
    private String asunto;
    private String texto;

    public MailBean() {
    }

    public MailBean(String destino, String asunto, String texto) {
        this.destino = destino;
        this.asunto = asunto;
        this.texto = texto;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }
    
    public void notificar(){
        if (EmailSender.enviarEmail(destino, asunto, texto)) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Ok", "Notificacion enviada correctamente"));
        }else{
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", "Notificacion no se pudo enviar"));
            
        }
    }
    
    
}
