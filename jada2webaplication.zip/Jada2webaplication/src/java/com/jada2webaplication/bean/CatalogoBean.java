package com.jada2webaplication.bean;

import com.jada2webaplication.entity.Catalogo;
import com.jada2webaplication.facateImp.CatalogoImp;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.PrimeFaces;

@Named("catalogoBean")
@ViewScoped
public class CatalogoBean implements Serializable {

    private List<Catalogo> catalogos;

    private Catalogo catalogo;

    private int Id_Catalogo;

    @Inject
    private CatalogoImp catalogoImp;

    @PostConstruct
    public void init() {
        try {
            this.catalogos = this.catalogoImp.findAll();
            this.catalogo = new Catalogo();
        } catch (Exception e) {
            e.getMessage();
        }
    }

    public List<Catalogo> getCatalogos() {
        return catalogos;
    }

    public void setCatalogos(List<Catalogo> catalogos) {
        this.catalogos = catalogos;
    }

    public Catalogo getCatalogo() {
        return catalogo;
    }

    public void setCatalogo(Catalogo catalogo) {
        this.catalogo = catalogo;
    }

    public int getId_Catalogo() {
        return Id_Catalogo;
    }

    public void setId_Catalogo(int Id_Catalogo) {
        this.Id_Catalogo = Id_Catalogo;
    }

    public CatalogoImp getCatalogoImp() {
        return catalogoImp;
    }

    public void setCatalogoImp(CatalogoImp catalogoImp) {
        this.catalogoImp = catalogoImp;
    }

    public void deleteCatalogo(Catalogo catalogo) {
        try {
            this.catalogoImp.delete(catalogo);
            this.catalogos.remove(catalogo);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Catalogo Removed"));
            PrimeFaces.current().ajax().update("formCatalogo:messages", "formCatalogo:listCatalogo");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void agregarCatalogo() {
        try {
            this.catalogoImp.add(catalogo);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro exitoso", "Catalogo Registrado exitosamente"));
            PrimeFaces.current().ajax().update("formCatalogo:messages", "formCatalogo:listCatalogo");
            init();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Fallo", e.getMessage()));
        }
    }

    public void editarCatalogo() {
        try {
            this.catalogoImp.update(this.catalogo);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Editado exitosamente", "Catalogo ha sido Editado exitosamente"));
            PrimeFaces.current().ajax().update("formCatalogo", "editCat");
            init();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Editado exitosamente", "Catalogo ha sido Editado exitosamente"));
        }
    }

    public void mostrarInfo(Catalogo catalogo) {
        try {
            this.catalogo = this.catalogoImp.findById(catalogo.getId_Catalogo());
            PrimeFaces.current().ajax().update("editCat");
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Error", e.getMessage()));
        }
    }

}
