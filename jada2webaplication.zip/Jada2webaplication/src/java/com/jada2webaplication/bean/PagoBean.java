package com.jada2webaplication.bean;

import com.jada2webaplication.entity.Pago;
import com.jada2webaplication.entity.Usuario;
import com.jada2webaplication.facateImp.PagoImp;
import com.jada2webaplication.facateImp.UsuarioImp;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.PrimeFaces;

@Named("pagoBean")
@ViewScoped
public class PagoBean implements Serializable {

    private List<Pago> pagos;
    private List<Usuario> usuarios;

    private Usuario usuario;
    private Pago pago;

    private int Id_Usuario;
    private int Id_Pago;

    @Inject
    private PagoImp pagoImp;
    @Inject
    private UsuarioImp usuarioImp;

    @PostConstruct
    public void init() {
        try {
            this.usuarios = this.usuarioImp.findAll();
            this.pagos = this.pagoImp.findAll();
            this.usuario = new Usuario();
            this.pago = new Pago();
        } catch (Exception e) {
            e.getMessage();
        }
    }

    public List<Pago> getPagos() {
        return pagos;
    }

    public void setPagos(List<Pago> pagos) {
        this.pagos = pagos;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Pago getPago() {
        return pago;
    }

    public void setPago(Pago pago) {
        this.pago = pago;
    }

    public int getId_Usuario() {
        return Id_Usuario;
    }

    public void setId_Usuario(int Id_Usuario) {
        this.Id_Usuario = Id_Usuario;
    }

    public int getId_Pago() {
        return Id_Pago;
    }

    public void setId_Pago(int Id_Pago) {
        this.Id_Pago = Id_Pago;
    }

    public PagoImp getPagoImp() {
        return pagoImp;
    }

    public void setPagoImp(PagoImp pagoImp) {
        this.pagoImp = pagoImp;
    }

    public UsuarioImp getUsuarioImp() {
        return usuarioImp;
    }

    public void setUsuarioImp(UsuarioImp usuarioImp) {
        this.usuarioImp = usuarioImp;
    }

    public void deletePago(Pago pagos) {
        try {
            this.pagoImp.delete(pagos);
            this.pagos.remove(pagos);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Pago Removed"));
            PrimeFaces.current().ajax().update("formRol:messages", "formRol:listPago");
        } catch (Exception e) {
        }

    }

    public void agregarPago() {
        try {
            this.pago.setId_UsuarioFk(usuario);
            this.pagoImp.add(pago);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro exitoso", "Pago Registrado exitosamente"));
            PrimeFaces.current().ajax().update("formUsuario:messages", "formUsuario:listUsuario");
            init();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Fallo", e.getMessage()));
        }
    }

    public void editarPago() {
        try {
            usuario = this.usuarioImp.findById(Id_Usuario);
            this.pago.setId_UsuarioFk(usuario);
            this.pagoImp.update(pago);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Modificacion exitosa", "Pago modificado exitosamente"));
            PrimeFaces.current().ajax().update("formPago", "editPago");
            init();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Fallo", e.getMessage()));
        }
    }

    public void mostrarInfo(Pago pago) {
        try {
            this.pago = this.pagoImp.findById(pago.getId_Pago());
            this.Id_Usuario = this.pago.getId_UsuarioFk().getId_Usuario();
            PrimeFaces.current().ajax().update("editPago");

        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Error", e.getMessage()));

        }
    }

}
