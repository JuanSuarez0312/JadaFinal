package com.jada2webaplication.bean;

import com.jada2webaplication.entity.Pqr;
import com.jada2webaplication.entity.RespuestaPqr;
import com.jada2webaplication.entity.Usuario;
import com.jada2webaplication.facateImp.PqrImp;
import com.jada2webaplication.facateImp.RespuestaPqrImp;
import com.jada2webaplication.facateImp.UsuarioImp;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.PrimeFaces;

@Named("respuestaPqrBean")
@ViewScoped
public class RespuestaPqrBean implements Serializable {

    private List<RespuestaPqr> respuestaPqrs;
    private List<Usuario> usuarios;
    private List<Pqr> pqrs;

    private RespuestaPqr respuestaPqr;
    private Usuario usuario;
    private Pqr pqr;

    private int Id_RespuestaPqrs;
    private int Id_Usuario;
    private int Id_Pqr;

    @Inject
    private RespuestaPqrImp respuestaPqrImp;

    @Inject
    private UsuarioImp usuarioImp;

    @Inject
    PqrImp pqrImp;

    @PostConstruct
    public void init() {
        try {
            this.respuestaPqrs = this.respuestaPqrImp.findAll();
            this.usuarios = this.usuarioImp.findAll();
            this.pqrs = this.pqrImp.findAll();
            this.respuestaPqr = new RespuestaPqr();
            this.usuario = new Usuario();
            this.pqr = new Pqr();

        } catch (Exception e) {
            e.getMessage();
        }
    }

    public List<RespuestaPqr> getRespuestaPqrs() {
        return respuestaPqrs;
    }

    public void setRespuestaPqrs(List<RespuestaPqr> respuestaPqrs) {
        this.respuestaPqrs = respuestaPqrs;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public List<Pqr> getPqrs() {
        return pqrs;
    }

    public void setPqrs(List<Pqr> pqrs) {
        this.pqrs = pqrs;
    }

    public RespuestaPqr getRespuestaPqr() {
        return respuestaPqr;
    }

    public void setRespuestaPqr(RespuestaPqr respuestaPqr) {
        this.respuestaPqr = respuestaPqr;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Pqr getPqr() {
        return pqr;
    }

    public void setPqr(Pqr pqr) {
        this.pqr = pqr;
    }

    public int getId_RespuestaPqrs() {
        return Id_RespuestaPqrs;
    }

    public void setId_RespuestaPqrs(int Id_RespuestaPqrs) {
        this.Id_RespuestaPqrs = Id_RespuestaPqrs;
    }

    public int getId_Usuario() {
        return Id_Usuario;
    }

    public void setId_Usuario(int Id_Usuario) {
        this.Id_Usuario = Id_Usuario;
    }

    public int getId_Pqr() {
        return Id_Pqr;
    }

    public void setId_Pqr(int Id_Pqr) {
        this.Id_Pqr = Id_Pqr;
    }

    public RespuestaPqrImp getRespuestaPqrImp() {
        return respuestaPqrImp;
    }

    public void setRespuestaPqrImp(RespuestaPqrImp respuestaPqrImp) {
        this.respuestaPqrImp = respuestaPqrImp;
    }

    public UsuarioImp getUsuarioImp() {
        return usuarioImp;
    }

    public void setUsuarioImp(UsuarioImp usuarioImp) {
        this.usuarioImp = usuarioImp;
    }

    public PqrImp getPqrImp() {
        return pqrImp;
    }

    public void setPqrImp(PqrImp pqrImp) {
        this.pqrImp = pqrImp;
    }

    public void deleteRespuestaPqr(RespuestaPqr respuestaPqrs) {
        try {
            this.respuestaPqrImp.delete(respuestaPqrs);
            this.respuestaPqrs.remove(respuestaPqrs);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Respuesta Removed"));
            PrimeFaces.current().ajax().update("formRespuestaPqr:messages", "formRespuestaPqr:listRespuestaPqr");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void responder() {
        try {
            this.usuario.setId(8);
            this.respuestaPqr.setId_UsuarioFk(usuario);
            this.respuestaPqr.setId_PqrsFk(pqr);
            this.respuestaPqrImp.add(respuestaPqr);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Respuesta exitosa", "Se ha respondido la Pqrs"));
            PrimeFaces.current().ajax().update("formRespuestaPqr:messages", "formRespuestaPqr:listRespuestaPqr");
            init();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Fallo", e.getMessage()));
        }
    }

    public void editarRespuesta() {
        try {
            usuario = this.usuarioImp.findById(Id_Usuario);
            pqr = this.pqrImp.findById(Id_Pqr);
            this.respuestaPqr.setId_UsuarioFk(usuario);
            this.respuestaPqr.setId_PqrsFk(pqr);
            this.respuestaPqrImp.update(respuestaPqr);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Modificacion exitosa", "Se ha editado la respuesta a la Pqrs"));
            PrimeFaces.current().ajax().update("formRespuestaPqr:messages", "formRespuestaPqr:listRespuestaPqr", "editRe");
            init();
        } catch (Exception e) {
        }
    }

    public void mostrarInfo(RespuestaPqr respuestaPqr) {
        try {
            this.respuestaPqr = this.respuestaPqrImp.findById(respuestaPqr.getId_Respuesta());
            this.Id_Usuario = this.respuestaPqr.getId_UsuarioFk().getId_Usuario();
            this.Id_Pqr = this.respuestaPqr.getId_PqrsFk().getId_Pqrs();
            PrimeFaces.current().ajax().update("editRe");
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Error", e.getMessage()));
        }
    }

}
