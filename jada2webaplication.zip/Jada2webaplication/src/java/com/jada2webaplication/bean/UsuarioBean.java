package com.jada2webaplication.bean;

import com.jada2webaplication.entity.Rol;
import com.jada2webaplication.entity.Usuario;
import com.jada2webaplication.facateImp.RolImp;
import com.jada2webaplication.facateImp.UsuarioImp;
import com.jada2webaplication.utilities.EmailSender;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.PrimeFaces;

@Named("usuarioBean")
@ViewScoped
public class UsuarioBean implements Serializable {

    private List<Usuario> usuarios;
    private List<Rol> listRoles;

    private Usuario usuario;
    private Rol rol;

    private int id_Rol;
    private int Id_Usuario;

    @Inject
    private UsuarioImp usuarioImp;
    @Inject
    private RolImp rolImp;

    @PostConstruct
    public void init() {
        try {
            this.listRoles = this.rolImp.findAll();
            this.usuarios = this.usuarioImp.findAll();
            this.usuario = new Usuario();
            this.rol = new Rol();
        } catch (Exception e) {
            e.getMessage();
        }
    }

    public int getId_Rol() {
        return id_Rol;
    }

    public void setId_Rol(int Id_Rol) {
        this.id_Rol = Id_Rol;
    }

    public int getId_Usuario() {
        return Id_Usuario;
    }

    public void setId_Usuario(int Id_Usuario) {
        this.Id_Usuario = Id_Usuario;
    }

    public List<Rol> getListRoles() {
        return listRoles;
    }

    public void setListRoles(List<Rol> listRoles) {
        this.listRoles = listRoles;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }

    public UsuarioImp getUsuarioImp() {
        return usuarioImp;
    }

    public void setUsuarioImp(UsuarioImp usuarioImp) {
        this.usuarioImp = usuarioImp;
    }

    public RolImp getRolImp() {
        return rolImp;
    }

    public void setRolImp(RolImp rolImp) {
        this.rolImp = rolImp;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public void deleteUsuario(Usuario usuario) {
        try {
            this.usuarioImp.delete(usuario);
            this.usuarios.remove(usuario);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Usuario Removed"));
            PrimeFaces.current().ajax().update("formUsuario:messages", "formUsuario:listUsuario");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void registrarUsuario() {
        try {
            this.rol.setId_Rol(2);
            this.usuario.setIdRolFk(rol);
            this.usuarioImp.add(usuario);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro exitoso", "Usuario Registrado exitosamente"));

        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Fallo", e.getMessage()));
        }
    }

    public void añadirUsuario() {
        try {
            this.usuario.setIdRolFk(rol);
            this.usuarioImp.add(usuario);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro exitoso", "Usuario Registrado exitosamente"));
            PrimeFaces.current().ajax().update("formUsuario:messages", "formUsuario:listUsuario");
            init();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Fallo", e.getMessage()));
        }
    }

    public void editarUsuario() {
        try {
            rol = this.rolImp.findById(id_Rol);
            this.usuario.setIdRolFk(rol);
            this.usuarioImp.update(this.usuario);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Modificacion exitosa", "Usuario editado exitosamente"));
            PrimeFaces.current().ajax().update("formUsuario", "editUser");
            init();

        } catch (Exception e) {
        }
    }

    public void mostrarInfo(Usuario usuario) {
        try {
            this.usuario = this.usuarioImp.findById(usuario.getId_Usuario());
            this.id_Rol = this.usuario.getIdRolFk().getId_Rol();
            PrimeFaces.current().ajax().update("editUser");
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Error", e.getMessage()));
        }
    }

    public void recuperarContraseña() {
        Usuario usPass;
        try {
            usPass = this.usuarioImp.userByEmail(usuario);
            if (usPass != null) {
                this.usuario = usPass;
                this.usuario = this.usuarioImp.findById(usuario.getId_Usuario());

                String destinatario = usPass.getCorreo();
                String asunto = "ANAC Makeup - Recuperar contraseña";
                String cuerpo = "Hola " + usuario.getNomUsuario() + ". La contraseña de tu cuenta es: " + usPass.getContraseña();
                if (EmailSender.enviarEmail(destinatario, asunto, cuerpo)) {
                    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Aviso", "Se envio la informacion correspondiente a su correo"));
                } else {
                    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Aviso", "El correo no se pudo enviar"));
                }
            } else {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Aviso", "El correo ingresado no existe en el sistema"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            e.getMessage();
        }
    }

}
