package com.jada2webaplication.bean;

import com.jada2webaplication.entity.Catalogo;
import com.jada2webaplication.entity.Producto;
import com.jada2webaplication.facateImp.CatalogoImp;
import com.jada2webaplication.facateImp.ProductoImp;
import com.jada2webaplication.utilities.Carrito;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.PrimeFaces;

@Named("productoBean")
@ViewScoped
public class ProductoBean implements Serializable {

    private List<Producto> productos;
    private List<Catalogo> catalogos;

    private Catalogo catalogo;

    private int Id_Producto;
    private int Id_Catalogo;

    private List<Carrito> productosCarrito = new ArrayList(); //Lista del carrito de compras con los productos, aqui se almacenan los productos agregados

    private Producto agregarProducto; //Objeto de producto para utilizar en el dashboard, en el momento de añadir un nuevo producto es necesario

    Producto producto = new Producto();

    @Inject
    private ProductoImp productoImp;

    @Inject
    private CatalogoImp catalogoImp;

    @PostConstruct
    public void init() {
        try {
            this.catalogos = this.catalogoImp.findAll();
            this.producto = new Producto();
            this.catalogo = new Catalogo();
            this.agregarProducto = new Producto();
            this.productos = this.productoImp.findAll();
        } catch (Exception e) {
            e.printStackTrace();
            e.getMessage();
        }
    }

    //CRUD
    public List<Producto> getProductos() {
        return productos;
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }

    public List<Catalogo> getCatalogos() {
        return catalogos;
    }

    public void setCatalogos(List<Catalogo> catalogos) {
        this.catalogos = catalogos;
    }

    public Catalogo getCatalogo() {
        return catalogo;
    }

    public void setCatalogo(Catalogo catalogo) {
        this.catalogo = catalogo;
    }

    public int getId_Producto() {
        return Id_Producto;
    }

    public void setId_Producto(int Id_Producto) {
        this.Id_Producto = Id_Producto;
    }

    public int getId_Catalogo() {
        return Id_Catalogo;
    }

    public void setId_Catalogo(int Id_Catalogo) {
        this.Id_Catalogo = Id_Catalogo;
    }

    public List<Carrito> getProductosCarrito() {
        return productosCarrito;
    }

    public void setProductosCarrito(List<Carrito> productosCarrito) {
        this.productosCarrito = productosCarrito;
    }

    public Producto getAgregarProducto() {
        return agregarProducto;
    }

    public void setAgregarProducto(Producto agregarProducto) {
        this.agregarProducto = agregarProducto;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public ProductoImp getProductoImp() {
        return productoImp;
    }

    public void setProductoImp(ProductoImp productoImp) {
        this.productoImp = productoImp;
    }

    public CatalogoImp getCatalogoImp() {
        return catalogoImp;
    }

    public void setCatalogoImp(CatalogoImp catalogoImp) {
        this.catalogoImp = catalogoImp;
    }

    public int getProductoCarrito() {
        return productoCarrito;
    }

    public void setProductoCarrito(int productoCarrito) {
        this.productoCarrito = productoCarrito;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }

    public void deleteProducto(Producto producto) {
        try {
            this.productoImp.delete(producto);
            this.productos.remove(producto);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Producto Removed"));
            PrimeFaces.current().ajax().update("formRol:messages", "formRol:listProducto");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Agregar producto
    public void añadirProducto() {
        try {
            this.producto.setId_CatalogoFk(catalogo);
            this.productoImp.add(producto);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro exitoso", "Producto Registrado exitosamente"));
            PrimeFaces.current().ajax().update("formProducto:messages", "formProducto:listProducto");
            init();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Fallo", e.getMessage()));

        }

    }

    //Editar producto{
    public void editarProducto() {
        try {
            catalogo = this.catalogoImp.findById(Id_Catalogo);
            this.producto.setId_CatalogoFk(catalogo);
            this.productoImp.update(producto);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Modificacion exitosa", "Producto Editado exitosamente"));
            PrimeFaces.current().ajax().update("formProducto", "editProducto");
            init();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Fallo", e.getMessage()));
        }
    }

    public void mostrarInfo(Producto producto) {
        try {
            this.producto = this.productoImp.findById(producto.getId_Producto());
            this.Id_Catalogo = this.producto.getId_CatalogoFk().getId_Catalogo();
            PrimeFaces.current().ajax().update("editProducto");
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Fallo", e.getMessage()));
        }
    }

    //Carrito de Compras
    private int productoCarrito;
    private double total = 0.0;
    private int cantidad = 1;
    private int contador;

    public void aumentarCantidad(int id) {
        try {
            int posicion = 0;
            cantidad = 1;
            this.producto = this.productoImp.findById(id);

            if (productosCarrito.size() > 0) {
                for (int i = 0; i < productosCarrito.size(); i++) {
                    if (id == productosCarrito.get(i).getIdProducto()) {
                        posicion = i;
                    }
                }
                if (id == productosCarrito.get(posicion).getIdProducto()) {
                    cantidad = productosCarrito.get(posicion).getCantidad() + cantidad;
                    double subTotal = productosCarrito.get(posicion).getPrecio() * cantidad;
                    productosCarrito.get(posicion).setCantidad(cantidad);
                    productosCarrito.get(posicion).setSubTotal(subTotal);
                } else {
                    productoCarrito = productoCarrito + 1;

                    Carrito cart = new Carrito();
                    cart.setProducto(productoCarrito);
                    cart.setIdProducto(producto.getId_Producto());
                    cart.setPrecio(producto.getPrecio());
                    cart.setNombreProducto(producto.getNomProd());
                    cart.setDescripcion(producto.getDescProd());
                    cart.setCantidad(cantidad);
                    cart.setSubTotal(cantidad * producto.getPrecio());
                    this.productosCarrito.add(cart);
                    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Carrito", "Se ha agregado el producto al carrito"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            e.getMessage();
        }
    }

}
