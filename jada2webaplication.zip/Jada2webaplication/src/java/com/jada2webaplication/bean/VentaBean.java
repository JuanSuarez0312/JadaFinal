package com.jada2webaplication.bean;

import com.jada2webaplication.entity.Pago;
import com.jada2webaplication.entity.Producto;
import com.jada2webaplication.entity.Usuario;
import com.jada2webaplication.entity.Venta;
import com.jada2webaplication.facateImp.PagoImp;
import com.jada2webaplication.facateImp.ProductoImp;
import com.jada2webaplication.facateImp.UsuarioImp;
import com.jada2webaplication.facateImp.VentaImp;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.PrimeFaces;

@Named("ventaBean")
@ViewScoped
public class VentaBean implements Serializable {

    private List<Venta> ventas;
    private List<Usuario> usuarios;
    private List<Producto> productos;
    private List<Pago> pagos;

    private Venta venta;
    private Usuario usuario;
    private Producto producto;
    private Pago pago;

    private int Id_Venta;
    private int Id_Usuario;
    private int Id_Producto;
    private int Id_Pago;

    @Inject
    private VentaImp ventaImp;
    @Inject
    private UsuarioImp usuarioImp;
    @Inject
    private ProductoImp productoImp;
    @Inject
    private PagoImp pagoImp;

    @PostConstruct
    public void init() {
        try {
            this.ventas = this.ventaImp.findAll();
            this.usuarios = this.usuarioImp.findAll();
            this.productos = this.productoImp.findAll();
            this.pagos = this.pagoImp.findAll();
            this.venta = new Venta();
            this.usuario = new Usuario();
            this.producto = new Producto();
            this.pago = new Pago();
        } catch (Exception e) {
            e.getMessage();
        }
    }

    public List<Venta> getVentas() {
        return ventas;
    }

    public void setVentas(List<Venta> ventas) {
        this.ventas = ventas;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }

    public List<Pago> getPagos() {
        return pagos;
    }

    public void setPagos(List<Pago> pagos) {
        this.pagos = pagos;
    }

    public Venta getVenta() {
        return venta;
    }

    public void setVenta(Venta venta) {
        this.venta = venta;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public Pago getPago() {
        return pago;
    }

    public void setPago(Pago pago) {
        this.pago = pago;
    }

    public int getId_Venta() {
        return Id_Venta;
    }

    public void setId_Venta(int Id_Venta) {
        this.Id_Venta = Id_Venta;
    }

    public int getId_Usuario() {
        return Id_Usuario;
    }

    public void setId_Usuario(int Id_Usuario) {
        this.Id_Usuario = Id_Usuario;
    }

    public int getId_Producto() {
        return Id_Producto;
    }

    public void setId_Producto(int Id_Producto) {
        this.Id_Producto = Id_Producto;
    }

    public int getId_Pago() {
        return Id_Pago;
    }

    public void setId_Pago(int Id_Pago) {
        this.Id_Pago = Id_Pago;
    }

    public VentaImp getVentaImp() {
        return ventaImp;
    }

    public void setVentaImp(VentaImp ventaImp) {
        this.ventaImp = ventaImp;
    }

    public UsuarioImp getUsuarioImp() {
        return usuarioImp;
    }

    public void setUsuarioImp(UsuarioImp usuarioImp) {
        this.usuarioImp = usuarioImp;
    }

    public ProductoImp getProductoImp() {
        return productoImp;
    }

    public void setProductoImp(ProductoImp productoImp) {
        this.productoImp = productoImp;
    }

    public PagoImp getPagoImp() {
        return pagoImp;
    }

    public void setPagoImp(PagoImp pagoImp) {
        this.pagoImp = pagoImp;
    }

    public void deleteVenta(Venta ventas) {
        try {
            this.ventaImp.delete(ventas);
            this.ventas.remove(venta);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Venta Removed"));
            PrimeFaces.current().ajax().update("formVenta:messages", "fromVenta:listVenta");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void agregarVenta() {
        try {
            this.venta.setId_PagoFk(pago);
            this.venta.setId_ProductoFk(producto);
            this.venta.setId_UsuarioFk(usuario);
            this.ventaImp.add(venta);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro exitoso", "Venta Registrada exitosamente"));
            PrimeFaces.current().ajax().update("formVenta:messages", "formVenta:listVenta");
            init();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Fallo", e.getMessage()));
        }
    }

    public void editarVenta() {
        try {
            pago = this.pagoImp.findById(Id_Pago);
            this.venta.setId_PagoFk(pago);
            producto = this.productoImp.findById(Id_Producto);
            this.venta.setId_ProductoFk(producto);
            usuario = this.usuarioImp.findById(Id_Usuario);
            this.venta.setId_UsuarioFk(usuario);
            this.ventaImp.update(venta);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Modificacion exitosa", "Venta editada exitosamente"));
            PrimeFaces.current().ajax().update("formVenta", "editVent");
            init();

        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Fallo", e.getMessage()));
        }
    }

    public void mostrarInfo(Venta venta) {
        try {
            this.venta = this.ventaImp.findById(venta.getId_Venta());
            this.Id_Pago = this.venta.getId_PagoFk().getId_Pago();
            this.Id_Producto = this.venta.getId_ProductoFk().getId_Producto();
            this.Id_Usuario = this.venta.getId_UsuarioFk().getId_Usuario();
            PrimeFaces.current().ajax().update("editVent");

        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Fallo", e.getMessage()));
        }
    }
}
