package com.jada2webaplication.bean;

import com.jada2webaplication.entity.Producto;
import com.jada2webaplication.entity.Promocion;
import com.jada2webaplication.facateImp.ProductoImp;
import com.jada2webaplication.facateImp.PromocionImp;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.PrimeFaces;

@Named("promocionBean")
@ViewScoped
public class PromocionBean implements Serializable {

    private List<Promocion> listPromociones;
    private List<Producto> productos;

    private Promocion promocion;
    private Producto producto;

    private int idProducto;
    private int Id_Promocion;

    @Inject
    private PromocionImp promocionImp;
    @Inject
    private ProductoImp productoImp;

    @PostConstruct
    public void init() {
        try {
            this.productos = this.productoImp.findAll();
            this.listPromociones = this.promocionImp.findAll();
            this.promocion = new Promocion();
            this.producto = new Producto();
        } catch (Exception e) {
            e.getMessage();
        }
    }

    public List<Promocion> getListPromociones() {
        return listPromociones;
    }

    public void setListPromociones(List<Promocion> listPromociones) {
        this.listPromociones = listPromociones;
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }

    public Promocion getPromocion() {
        return promocion;
    }

    public void setPromocion(Promocion promocion) {
        this.promocion = promocion;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getId_Promocion() {
        return Id_Promocion;
    }

    public void setId_Promocion(int Id_Promocion) {
        this.Id_Promocion = Id_Promocion;
    }

    public PromocionImp getPromocionImp() {
        return promocionImp;
    }

    public void setPromocionImp(PromocionImp promocionImp) {
        this.promocionImp = promocionImp;
    }

    public ProductoImp getProductoImp() {
        return productoImp;
    }

    public void setProductoImp(ProductoImp productoImp) {
        this.productoImp = productoImp;
    }

    public void deletePromocion(Promocion promocion) {
        try {
            this.promocionImp.delete(promocion);
            this.listPromociones.remove(promocion);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Promocion Removed"));
            PrimeFaces.current().ajax().update("formPromocion:messages", "formPromocion:listPromocion");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void crearPromocion() {
        try {
            this.promocion.setId_ProductoFk(producto);
            this.promocionImp.add(promocion);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro exitoso", "Promocion Registrada exitosamente"));
            PrimeFaces.current().ajax().update("formPromocion:messages", "formPromocion:listPromocion");
            init();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Fallo", e.getMessage()));
        }
    }

    public void editarPromocion() {
        try {
            producto = this.productoImp.findById(idProducto);
            this.promocion.setId_ProductoFk(producto);
            this.promocionImp.update(this.promocion);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Modificacion exitosa", "Promocion Editada exitosamente"));
            PrimeFaces.current().ajax().update("formPromocion", "editP");
            init();

        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Fallo", e.getMessage()));
        }
    }

    public void mostrarInfo(Promocion promocion) {
        try {
            this.promocion = this.promocionImp.findById(promocion.getId_Promociones());
            this.idProducto = this.promocion.getId_ProductoFk().getId_Producto();
            PrimeFaces.current().ajax().update("editP");
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Error", e.getMessage()));
        }
    }

}
