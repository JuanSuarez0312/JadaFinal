package com.jada2webaplication.bean;

import com.jada2webaplication.entity.Usuario;
import com.jada2webaplication.facateImp.UsuarioImp;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named("loginBean")
@ViewScoped
public class LoginBean implements Serializable {

    private Usuario usuario;

    @Inject
    private UsuarioImp usuarioImp;

    @PostConstruct
    public void init() {
        this.usuario = new Usuario();
    }

    public LoginBean() {
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String iniciarSesion() {
        String url = "";
        Usuario us;
        try {
            us = this.usuarioImp.validarUsuario(usuario);
            if (us != null) {
                if (us.getIdRolFk().getId_Rol() == 1) {
                    url = "/plantilla/admin?faces-redirect=true";
                    FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("usuario", us);

                } else {
                    url = "/plantilla/client?faces-redirect=true";
                    FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("usuario", us);
                }

            } else {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", "Credenciales incorrectas"));
            }
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Fallo", e.getMessage()));
        }
        return url;
    }

    public void validar() {
        try {
            Usuario usu = (Usuario) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("usuario");
            if (usu == null) {
                FacesContext.getCurrentInstance().getExternalContext().redirect("http://localhost:8080/Jada2webaplication/");
            }
        } catch (Exception e) {
        }
    }

    public void cerrarSesion() {
        try {
            FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
            FacesContext.getCurrentInstance().getExternalContext().redirect("http://localhost:8080/Jada2webaplication/");
        } catch (Exception e) {
        }
    }
}
