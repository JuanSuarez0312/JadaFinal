package com.jada2webaplication.facade;

import com.jada2webaplication.entity.Pqr;
import java.util.List;

public interface IPqr {
    public List<Pqr> findAll() throws Exception;
    public Pqr findById(int id) throws Exception;
    public void add(Pqr pqr) throws Exception;
    public void update(Pqr pqr) throws Exception;
    public void delete(Pqr pqr) throws Exception;
}
