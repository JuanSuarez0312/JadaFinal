package com.jada2webaplication.facade;

import com.jada2webaplication.entity.RespuestaPqr;
import java.util.List;

public interface IRespuestaPqr {
    public List<RespuestaPqr> findAll() throws Exception;
    public RespuestaPqr findById(int id) throws Exception;
    public void add(RespuestaPqr respuestaPqr) throws Exception;
    public void update(RespuestaPqr respuestaPqr) throws Exception;
    public void delete(RespuestaPqr respuestaPqr) throws Exception;
}
