package com.jada2webaplication.facade;

import com.jada2webaplication.entity.Catalogo;
import java.util.List;

public interface ICatalogo {
    public List<Catalogo> findAll() throws Exception;
    public Catalogo findById(int id) throws Exception;
    public void add(Catalogo catalogo) throws Exception;
    public void update(Catalogo catalogo) throws Exception;
    public void delete(Catalogo catalogo) throws Exception;
}
