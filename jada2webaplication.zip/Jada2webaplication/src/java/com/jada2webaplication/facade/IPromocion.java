package com.jada2webaplication.facade;

import com.jada2webaplication.entity.Promocion;
import java.util.List;

public interface IPromocion {

    public List<Promocion> findAll() throws Exception;
    public Promocion findById(int id) throws Exception;
    public void add(Promocion promocion) throws Exception;
    public void update(Promocion promocion) throws Exception;
    public void delete(Promocion promocion) throws Exception;
}
