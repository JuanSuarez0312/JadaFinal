package com.jada2webaplication.facade;

import com.jada2webaplication.entity.Pago;
import java.util.List;

public interface IPago {
    public List<Pago> findAll() throws Exception;
    public Pago findById(int id) throws Exception;
    public void add(Pago pago) throws Exception;
    public void update(Pago pago) throws Exception;
    public void delete(Pago pago) throws Exception;
}
