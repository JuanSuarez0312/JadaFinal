package com.jada2webaplication.facade;

import com.jada2webaplication.entity.Producto;
import java.util.List;

public interface IProducto {
    public List<Producto> findAll() throws Exception;
    public Producto findById(int id) throws Exception;
    public void add(Producto producto) throws Exception;
    public void update(Producto producto) throws Exception;
    public void delete(Producto producto) throws Exception;
}
